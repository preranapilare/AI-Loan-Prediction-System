import pandas as pd

from sklearn.model_selection import train_test_split

from sklearn.linear_model import LogisticRegression

import joblib


# Read dataset
data = pd.read_csv("loan_data.csv")

# Features
X = data[['income', 'loan_amount', 'credit_score', 'employment']]

# Output
y = data['loan_status']

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# Create model
model = LogisticRegression()

# Train model
model.fit(X_train, y_train)

# Save model
joblib.dump(model, 'loan_model.pkl')

print("Model Trained Successfully")