from django.shortcuts import render, redirect

from django.contrib.auth.models import User, Group

from django.contrib.auth import authenticate, login, logout


# REGISTER

def register(request):

    error = ""

    if request.method == "POST":

        username = request.POST['username']

        password = request.POST['password']

        role = request.POST['role']


        # CHECK IF USER EXISTS

        if User.objects.filter(username=username).exists():

            error = "Username already exists"

            return render(request, 'register.html', {

                'error': error

            })


        # CREATE USER

        user = User.objects.create_user(

            username=username,

            password=password

        )


        # ADD ROLE

        if role == "employee":

            group, created = Group.objects.get_or_create(

                name='Employee'

            )

            user.groups.add(group)


        return redirect('/accounts/login/')


    return render(request, 'register.html')


# LOGIN

def user_login(request):

    error = ""

    if request.method == "POST":

        username = request.POST['username']

        password = request.POST['password']


        user = authenticate(

            request,

            username=username,

            password=password

        )


        if user is not None:

            login(request, user)

            return redirect('/')

        else:

            error = "Invalid Username or Password"


    return render(request, 'login.html', {

        'error': error

    })


# LOGOUT

def user_logout(request):

    logout(request)

    return redirect('/accounts/login/')