from django.urls import path

from . import views


urlpatterns = [

    path('', views.home, name='home'),

    path('history/', views.history, name='history'),

    path('dashboard/', views.dashboard, name='dashboard'),

    path('csv-upload/', views.csv_upload, name='csv_upload'),

]