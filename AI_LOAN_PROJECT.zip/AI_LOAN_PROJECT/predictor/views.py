import pandas as pd

from django.core.files.storage import FileSystemStorage
from django.shortcuts import render, redirect

from .models import LoanPrediction

from django.contrib.auth.decorators import login_required

import joblib

import math

model = joblib.load('loan_model.pkl')


# HOME PAGE

@login_required
def home(request):

    result = ""

    emi = None

    if request.method == "POST":

        income = float(request.POST['income'])

        loan_amount = float(request.POST['loan_amount'])

        credit_score = float(request.POST['credit_score'])

        employment_value = request.POST['employment']

        employment = int(employment_value)

        employment_text = "Employed" if employment == 1 else "Unemployed"


        # FRAUD DETECTION

        if loan_amount > income * 10:

            result = "Possible Fraud Detected"

        else:

            prediction = model.predict([
                [income, loan_amount, credit_score, employment]
            ])

            if prediction[0] == 1:

                result = "Loan Approved"

            else:

                result = "Loan Rejected"


        # EMI CALCULATION

        principal = loan_amount

        annual_interest_rate = 10

        monthly_interest_rate = annual_interest_rate / 12 / 100

        months = 5 * 12


        emi = (

            principal

            * monthly_interest_rate

            * math.pow(1 + monthly_interest_rate, months)

        ) / (

            math.pow(1 + monthly_interest_rate, months) - 1

        )


        # SAVE TO DATABASE

        LoanPrediction.objects.create(

            user=request.user,

            income=income,

            loan_amount=loan_amount,

            credit_score=credit_score,

            employment=employment_text,

            result=result

        )

    return render(request, 'home.html', {

        'result': result,

        'emi': round(emi, 2) if emi else None

    })


# USER HISTORY

@login_required
def history(request):

    data = LoanPrediction.objects.filter(

        user=request.user

    ).order_by('-created_at')

    return render(request, 'history.html', {'data': data})


# EMPLOYEE DASHBOARD

@login_required
def dashboard(request):

    if not (
        request.user.groups.filter(name='Employee').exists()
        or request.user.is_superuser
    ):

        return redirect('/')


    total = LoanPrediction.objects.count()

    approved = LoanPrediction.objects.filter(
        result="Loan Approved"
    ).count()

    rejected = LoanPrediction.objects.filter(
        result="Loan Rejected"
    ).count()

    fraud = LoanPrediction.objects.filter(
        result="Possible Fraud Detected"
    ).count()


    all_data = LoanPrediction.objects.all().order_by('-created_at')


    return render(request, 'dashboard.html', {

        'total': total,

        'approved': approved,

        'rejected': rejected,

        'fraud': fraud,

        'all_data': all_data,

    })
@login_required
def csv_upload(request):

    if not (
        request.user.groups.filter(name='Employee').exists()
        or request.user.is_superuser
    ):

        return redirect('/')


    predictions = []


    if request.method == 'POST' and request.FILES['file']:

        file = request.FILES['file']

        fs = FileSystemStorage()

        filename = fs.save(file.name, file)

        file_path = fs.path(filename)


        df = pd.read_csv(file_path)


        for index, row in df.iterrows():

            income = row['income']

            loan_amount = row['loan_amount']

            credit_score = row['credit_score']

            employment = row['employment']


            # FRAUD DETECTION

            if loan_amount > income * 10:

                result = "Possible Fraud Detected"

            else:

                prediction = model.predict([[
                    income,
                    loan_amount,
                    credit_score,
                    employment
                ]])


                if prediction[0] == 1:

                    result = "Loan Approved"

                else:

                    result = "Loan Rejected"


            predictions.append({

                'income': income,

                'loan_amount': loan_amount,

                'credit_score': credit_score,

                'employment': employment,

                'result': result

            })


    return render(request,

                  'csv_upload.html',

                  {'predictions': predictions})