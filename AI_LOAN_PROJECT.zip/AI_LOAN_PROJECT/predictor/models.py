from django.db import models

from django.contrib.auth.models import User


class LoanPrediction(models.Model):

    user = models.ForeignKey(

        User,

        on_delete=models.CASCADE,

        null=True,

        blank=True

    )

    income = models.FloatField()

    loan_amount = models.FloatField()

    credit_score = models.FloatField()

    employment = models.CharField(max_length=20)

    result = models.CharField(max_length=100)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):

        return self.result